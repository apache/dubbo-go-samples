# Dubbo java and go interoperability, non-protobuf and triple protocol

Please refer to [Multiple Protocols](https://github.com/apache/dubbo-go-samples/tree/main/rpc/multi-protocols) for how to write non-protobuf style protocol.
    package org.apache.dubbo.tri.hessian2.api;

    import java.io.Serializable;

    public class GreetResponse implements Serializable{
        public String greeting;
    }
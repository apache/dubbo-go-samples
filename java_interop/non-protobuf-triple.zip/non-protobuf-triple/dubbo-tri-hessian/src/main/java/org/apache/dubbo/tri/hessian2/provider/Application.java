package org.apache.dubbo.tri.hessian2.provider;

import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.config.ProtocolConfig;
import org.apache.dubbo.config.RegistryConfig;
import org.apache.dubbo.config.ServiceConfig;
import org.apache.dubbo.config.ApplicationConfig;
import org.apache.dubbo.config.bootstrap.DubboBootstrap;
import org.apache.dubbo.tri.hessian2.api.GreetingsService;

import java.io.IOException;
public class Application {
//    public static void main(String[] args) {
//        // 定义具体的服务
//        ServiceConfig<GreetingsService> service = new ServiceConfig<>();
//        service.setInterface(GreetingsService.class);
//
//        service.setRef(new GreetingsServiceImpl());
//
//        // Launch Dubbo
//        DubboBootstrap.getInstance()
//                .application("first-dubbo-provider")
//                .registry(new RegistryConfig("zookeeper://127.0.0.1:2181"))
//                .protocol(new ProtocolConfig("tri", -1))
//                .service(service)
//                .start()
//                .await();
//    }//zookeeper version
public static void main(String[] args) throws IOException {
    ServiceConfig<GreetingsService> service =  new ServiceConfig<>();
    service.setInterface(GreetingsService.class);
    service.setRef(new GreetingsServiceImpl());

    DubboBootstrap bootstrap = DubboBootstrap.getInstance();
    ApplicationConfig appconf = new ApplicationConfig();
    appconf.setName("java-go-sample-server");
    bootstrap.application(new ApplicationConfig("java-go-sample-server"))
            .protocol(new ProtocolConfig(CommonConstants.TRIPLE,50052))
            .service(service)
            .start();
    System.out.println("Dubbo triple java server started");
    System.in.read();
}
}
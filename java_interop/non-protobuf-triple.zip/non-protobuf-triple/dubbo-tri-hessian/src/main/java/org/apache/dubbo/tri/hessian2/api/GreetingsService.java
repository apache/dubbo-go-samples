package org.apache.dubbo.tri.hessian2.api;

public interface GreetingsService {
    GreetResponse Greet(GreetRequest req);
}

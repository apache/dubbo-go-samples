package org.apache.dubbo.tri.hessian2.provider;

import org.apache.dubbo.tri.hessian2.api.GreetRequest;
import org.apache.dubbo.tri.hessian2.api.GreetResponse;
import org.apache.dubbo.tri.hessian2.api.GreetingsService;

public class GreetingsServiceImpl implements GreetingsService {
    @Override
    public GreetResponse Greet(GreetRequest req){
        GreetResponse response = new GreetResponse();
        response.greeting = "Hi," + req.name;
        return response;
    }
}
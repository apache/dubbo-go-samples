package org.apache.dubbo.tri.hessian2.consumer;

import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.config.ProtocolConfig;
import org.apache.dubbo.config.RegistryConfig;
import org.apache.dubbo.config.ConsumerConfig;
import org.apache.dubbo.config.ApplicationConfig;
import org.apache.dubbo.config.ReferenceConfig;
import org.apache.dubbo.config.bootstrap.DubboBootstrap;
import org.apache.dubbo.tri.hessian2.api.GreetRequest;
import org.apache.dubbo.tri.hessian2.api.GreetResponse;
import org.apache.dubbo.tri.hessian2.api.GreetingsService;

import java.io.IOException;
public class Application {
//    public static void main(String[] args) throws IOException {
//        ReferenceConfig<GreetingsService> reference = new ReferenceConfig<>();
//        reference.setInterface(GreetingsService.class);
//        reference.setProtocol("tri");
//
//        DubboBootstrap.getInstance()
//                .application("first-dubbo-consumer")
//                .registry(new RegistryConfig("zookeeper://127.0.0.1:2181"))
//                .reference(reference);
//
//        GreetingsService service = reference.get();
//        GreetRequest request = new GreetRequest();
//        request.name = "dubbo";
//        GreetResponse resp = service.Greet(request);
//        System.out.println("Receive result ======> " + resp.greeting);
//        System.in.read();
//    } //zookeeper ver
public static void main(String[] args) {
    DubboBootstrap bootstrap = DubboBootstrap.getInstance();
    ReferenceConfig<GreetingsService> ref = new ReferenceConfig<>();
    ref.setInterface(GreetingsService.class);
    ref.setTimeout(3000);
    ref.setUrl("tri://127.0.0.1:50052");
    ProtocolConfig protocol = new ProtocolConfig();
    protocol.setName("tri");
    protocol.setSerialization("hessian2");
    protocol.setRegister(false);

    bootstrap.application(new ApplicationConfig("dubbo-java-no-idl"))
            .reference(ref)
            .protocol(protocol)
            .start();

    GreetingsService greeter = ref.get();
    GreetRequest req = new GreetRequest();
    req.name = "dubbo-java";

    GreetResponse resp = greeter.Greet(req);
    System.out.println("Received reply:" + resp.greeting);
}
}

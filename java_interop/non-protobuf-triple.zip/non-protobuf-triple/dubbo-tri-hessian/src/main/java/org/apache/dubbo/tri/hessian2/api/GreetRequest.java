package org.apache.dubbo.tri.hessian2.api;

import java.io.Serializable;


public class GreetRequest implements Serializable {
    public String name;
}